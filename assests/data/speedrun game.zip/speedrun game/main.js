var canavas = document.getElementById("game")
var context = canavas.getContext("2d")
var playerX  = 0;
var playerY = 0;
var playerSize = 25;

var coinX = 0;
var coinY = 0;
var coinSize = 25;
var score = 0;
var timer = 0;

var won = false

var keys = [];
window.addEventListener("keydown",function(e) {
    keys[e.keyCode] = true
})
window.addEventListener("keyup",function(e) {
    keys[e.keyCode] = false
})
function init() {
    playerX = 400
    playerY = 300
    coinX = 400
    coinY = 500
    score = 0
}
function loop() {
    update()
    render()
}
function update() {
    if (keys[37] == true) {
        playerX = playerX - 10
    }
    if (keys[65] == true) {
        playerX = playerX - 10
    }
    if (keys[38] == true) {
        playerY = playerY - 10
    }
    if (keys[87] == true) {
        playerY = playerY - 10
    }
    if (keys[39] == true) {
        playerX = playerX + 10
    }
    if (keys[68] == true) {
        playerX = playerX + 10
    }
    if (keys[40] == true) {
        playerY = playerY + 10
    }
    if (keys[83] == true) {
        playerY = playerY + 10
    }
    if(playerX + playerSize > coinX && playerY + playerSize > coinY && coinX + coinSize > playerX && coinY + coinSize > playerY) {
        playerCollectedCoin()
    }
    if(score >= 100) {
        won = true
    }
}
function playerCollectedCoin() {
    playerSize = playerSize + 15
    coinX = Math.random()*(800-coinSize);
    coinY = Math.random()*(600-coinSize);
    score = score + 1
}
function render() {
    context.clearRect(0,0,800,600)
    context.fillStyle = "lightgreen";
    context.fillRect(0,0,800,600)
    context.fillStyle = "red"
    context.fillRect(playerX,playerY,playerSize,playerSize)
    context.fillStyle = "yellow"
    context.beginPath()
    context.arc(coinX + coinSize/2,coinY + coinSize/2,coinSize/2,coinSize/2,0,360)
    context.fill()

    context.fillStyle = "black"
    context.font = "40px Verdana"
    context.fillText("Score: " + score + "   Timer by seconds: " + Math.round(timer/60),0,40)

    if(won == true) {
        context.fillStyle = "green"
        context.fillText("You won! Your time was : " + Math.round(timer/60)+" seconds",20,100)
    }
    if(won == false) {
        timer = timer + 1
    }
}
window.setInterval(loop, 1000/60)

init()